
    
const quizQuestions = {
    "math": [
        { question: "What is 5 + 3?", options: ["6", "7", "8", "9"], answer: "8" },
        { question: "What is 12 / 4?", options: ["2", "3", "4", "6"], answer: "3" },
        { question: "What is 7 * 6?", options: ["42", "36", "40", "48"], answer: "42" },
        { question: "What is the square root of 64?", options: ["6", "7", "8", "9"], answer: "8" },
        { question: "What is 15 - 7?", options: ["6", "8", "9", "10"], answer: "8" },
        { question: "Solve: 3^2", options: ["6", "9", "12", "15"], answer: "9" },
        { question: "What is 100 / 10?", options: ["5", "10", "15", "20"], answer: "10" },
        { question: "What is 9 + 6?", options: ["13", "14", "15", "16"], answer: "15" },
        { question: "What is 20 - 12?", options: ["6", "7", "8", "9"], answer: "8" },
        { question: "Solve: 4 * 5", options: ["15", "18", "20", "25"], answer: "20" }
    ],
    
    "Gk": [
        { question: "What planet is known as the Red Planet?", options: ["Earth", "Mars", "Venus", "Jupiter"], answer: "Mars" },
        { question: "What is H2O commonly known as?", options: ["Oxygen", "Water", "Hydrogen", "Salt"], answer: "Water" },
        { question: "What gas do plants absorb?", options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], answer: "Carbon Dioxide" },
        { question: "What is the speed of light?", options: ["300,000 km/s", "150,000 km/s", "100,000 km/s", "500,000 km/s"], answer: "300,000 km/s" },
        { question: "Which organ pumps blood?", options: ["Lungs", "Brain", "Heart", "Kidney"], answer: "Heart" },
        { question: "What is the boiling point of water?", options: ["90°C", "100°C", "110°C", "120°C"], answer: "100°C" },
        { question: "What is the largest planet?", options: ["Earth", "Mars", "Jupiter", "Saturn"], answer: "Jupiter" },
        { question: "What part of the cell contains DNA?", options: ["Cytoplasm", "Nucleus", "Membrane", "Vacuole"], answer: "Nucleus" },
        { question: "What is the chemical symbol for gold?", options: ["Ag", "Au", "Gd", "Ge"], answer: "Au" },
        { question: "What force keeps us on the ground?", options: ["Friction", "Magnetism", "Gravity", "Air Pressure"], answer: "Gravity" }
    ],

    "history": [
        { question: "Who was the first President of the USA?", options: ["Abraham Lincoln", "George Washington", "Thomas Jefferson", "John Adams"], answer: "George Washington" },
        { question: "In which year did World War II end?", options: ["1942", "1945", "1948", "1950"], answer: "1945" },
        { question: "Who discovered America?", options: ["Marco Polo", "Christopher Columbus", "Ferdinand Magellan", "Vasco da Gama"], answer: "Christopher Columbus" },
        { question: "What was the Great Wall of China built for?", options: ["Trade", "Defense", "Tourism", "Agriculture"], answer: "Defense" },
        { question: "Who was known as the Iron Lady?", options: ["Queen Victoria", "Margaret Thatcher", "Cleopatra", "Joan of Arc"], answer: "Margaret Thatcher" },
        { question: "Which ancient civilization built the pyramids?", options: ["Romans", "Greeks", "Egyptians", "Aztecs"], answer: "Egyptians" },
        { question: "What year did the French Revolution begin?", options: ["1776", "1789", "1804", "1821"], answer: "1789" },
        { question: "Who was Julius Caesar?", options: ["A Roman Emperor", "A Greek Philosopher", "A French King", "An Egyptian Pharaoh"], answer: "A Roman Emperor" },
        { question: "What was the Cold War?", options: ["A conflict between USA and USSR", "A medieval war", "A global trade war", "A war of independence"], answer: "A conflict between USA and USSR" },
        { question: "Who wrote the Declaration of Independence?", options: ["George Washington", "Benjamin Franklin", "Thomas Jefferson", "John Adams"], answer: "Thomas Jefferson" }
    ],


   "sports": [
    { question: "How many players are there in a football team?", options: ["9", "10", "11", "12"], answer: "11" },
    { question: "What is the national sport of Japan?", options: ["Baseball", "Sumo Wrestling", "Soccer", "Karate"], answer: "Sumo Wrestling" },
    { question: "Which country hosted the 2016 Olympics?", options: ["China", "Brazil", "USA", "Russia"], answer: "Brazil" },
    { question: "How long is a marathon?", options: ["21 km", "42 km", "30 km", "50 km"], answer: "42 km" },
    { question: "What sport uses a shuttlecock?", options: ["Tennis", "Badminton", "Squash", "Cricket"], answer: "Badminton" },
    { question: "Who is known as the 'King of Football'?", options: ["Cristiano Ronaldo", "Lionel Messi", "Pelé", "Maradona"], answer: "Pelé" },
    { question: "How many rings are on the Olympic flag?", options: ["3", "4", "5", "6"], answer: "5" },
    { question: "What sport is played at Wimbledon?", options: ["Football", "Tennis", "Golf", "Cricket"], answer: "Tennis" },
    { question: "Which country is famous for the sport of rugby?", options: ["India", "USA", "New Zealand", "France"], answer: "New Zealand" },
    { question: "What is a baseball field also called?", options: ["Court", "Pitch", "Diamond", "Arena"], answer: "Diamond" }
],

"geography": [
    { question: "What is the capital of France?", options: ["Paris", "Rome", "Berlin", "Madrid"], answer: "Paris" },
    { question: "Which is the largest continent?", options: ["Africa", "Asia", "Europe", "Australia"], answer: "Asia" },
    { question: "Which river is the longest in the world?", options: ["Amazon", "Nile", "Yangtze", "Mississippi"], answer: "Nile" },
    { question: "Mount Everest is located in which country?", options: ["China", "India", "Nepal", "Bhutan"], answer: "Nepal" },
    { question: "What is the smallest ocean?", options: ["Indian", "Atlantic", "Arctic", "Pacific"], answer: "Arctic" },
    { question: "Which desert is the largest in the world?", options: ["Sahara", "Gobi", "Kalahari", "Arabian"], answer: "Sahara" },
    { question: "Which country has the largest population?", options: ["India", "USA", "China", "Russia"], answer: "China" },
    { question: "What is the capital of Canada?", options: ["Toronto", "Ottawa", "Vancouver", "Montreal"], answer: "Ottawa" },
    { question: "What is the longest mountain range?", options: ["Andes", "Himalayas", "Rockies", "Alps"], answer: "Andes" },
    { question: "Which sea is the saltiest?", options: ["Mediterranean", "Caspian", "Red Sea", "Dead Sea"], answer: "Dead Sea" }
],

"art": [
    { question: "Who painted the Mona Lisa?", options: ["Van Gogh", "Leonardo da Vinci", "Picasso", "Michelangelo"], answer: "Leonardo da Vinci" },
    { question: "What is the art of paper folding called?", options: ["Origami", "Kirigami", "Quilling", "Sketching"], answer: "Origami" },
    { question: "Which artist cut off his ear?", options: ["Van Gogh", "Da Vinci", "Rembrandt", "Monet"], answer: "Van Gogh" },
    { question: "What is the primary color not found in the rainbow?", options: ["Red", "Blue", "Black", "Green"], answer: "Black" },
    { question: "The Sistine Chapel ceiling was painted by?", options: ["Raphael", "Michelangelo", "Titian", "Donatello"], answer: "Michelangelo" },
    { question: "Who is the famous surrealist artist?", options: ["Van Gogh", "Salvador Dalí", "Cézanne", "Matisse"], answer: "Salvador Dalí" },
    { question: "What is Cubism associated with?", options: ["Van Gogh", "Picasso", "Monet", "Renoir"], answer: "Picasso" },
    { question: "What medium does a sculptor primarily use?", options: ["Paint", "Clay", "Canvas", "Charcoal"], answer: "Clay" },
    { question: "Who painted 'Starry Night'?", options: ["Picasso", "Van Gogh", "Rembrandt", "Da Vinci"], answer: "Van Gogh" },
    { question: "Which movement is associated with Monet?", options: ["Realism", "Surrealism", "Impressionism", "Romanticism"], answer: "Impressionism" }
],

"animal": [
    { question: "What is the largest land animal?", options: ["Elephant", "Hippopotamus", "Rhinoceros", "Giraffe"], answer: "Elephant" },
    { question: "Which animal is known as the 'King of the Jungle'?", options: ["Tiger", "Lion", "Leopard", "Panther"], answer: "Lion" },
    { question: "How many legs does a spider have?", options: ["6", "8", "10", "12"], answer: "8" },
    { question: "What is the fastest land animal?", options: ["Cheetah", "Horse", "Tiger", "Lion"], answer: "Cheetah" },
    { question: "What do pandas mainly eat?", options: ["Fish", "Grass", "Bamboo", "Leaves"], answer: "Bamboo" },
    { question: "Which bird cannot fly?", options: ["Eagle", "Ostrich", "Parrot", "Crow"], answer: "Ostrich" },
    { question: "Which mammal can fly?", options: ["Bat", "Squirrel", "Whale", "Kangaroo"], answer: "Bat" },
    { question: "What is a baby sheep called?", options: ["Calf", "Lamb", "Kid", "Pup"], answer: "Lamb" },
    { question: "What is a group of lions called?", options: ["Pack", "Troop", "Pride", "Herd"], answer: "Pride" },
    { question: "What is the tallest animal?", options: ["Elephant", "Giraffe", "Rhino", "Horse"], answer: "Giraffe" }
],

"celebrities": [
    { question: "Who is the actor famous for playing 'Iron Man'?", options: ["Chris Evans", "Robert Downey Jr.", "Chris Hemsworth", "Mark Ruffalo"], answer: "Robert Downey Jr." },
    { question: "Who is the singer of 'Shape of You'?", options: ["Justin Bieber", "Ed Sheeran", "Shawn Mendes", "Harry Styles"], answer: "Ed Sheeran" },
    { question: "Which actress starred in 'Pretty Woman'?", options: ["Julia Roberts", "Sandra Bullock", "Anne Hathaway", "Jennifer Aniston"], answer: "Julia Roberts" },
    { question: "Who played Jack in Titanic?", options: ["Brad Pitt", "Johnny Depp", "Leonardo DiCaprio", "Tom Hanks"], answer: "Leonardo DiCaprio" },
    { question: "Which singer is known as the 'Queen of Pop'?", options: ["Madonna", "Beyoncé", "Lady Gaga", "Rihanna"], answer: "Madonna" },
    { question: "Who played Harry Potter?", options: ["Rupert Grint", "Daniel Radcliffe", "Tom Felton", "Elijah Wood"], answer: "Daniel Radcliffe" },
    { question: "Which athlete is known as the fastest man in the world?", options: ["Usain Bolt", "Michael Phelps", "Carl Lewis", "Mo Farah"], answer: "Usain Bolt" },
    { question: "Who directed the movie 'Avatar'?", options: ["James Cameron", "Steven Spielberg", "Christopher Nolan", "Peter Jackson"], answer: "James Cameron" },
    { question: "Who is known as the 'King of Pop'?", options: ["Elvis Presley", "Prince", "Michael Jackson", "John Lennon"], answer: "Michael Jackson" },
    { question: "Which celebrity founded Tesla?", options: ["Jeff Bezos", "Elon Musk", "Bill Gates", "Steve Jobs"], answer: "Elon Musk" }
]

};

let currentQuestions = [];
let currentQuestionIndex = 0;
let score = 0;
let timer;
let timeLeft = 15;

const userNameInput = document.getElementById("user-name");
const quizTopicSelect = document.getElementById("quiz-topic");
const startQuizButton = document.getElementById("start-quiz");
const quizArea = document.getElementById("quiz-area");
const questionElement = document.getElementById("question");
const optionsContainer = document.getElementById("options");
const scoreCount = document.getElementById("score-count");
const nextQuestionButton = document.getElementById("next-question");
const timerDisplay = document.getElementById("time-left");
const winAnimation = document.getElementById("win-animation");
const finalScore = document.getElementById("final-score");
const winnerName = document.getElementById("winner-name");
const restartButton = document.getElementById("restart-quiz");
const leaderboardSection = document.getElementById("leaderboard-section");
const leaderboardList = document.getElementById("leaderboard-list");

startQuizButton.addEventListener("click", () => {
    const selectedTopic = quizTopicSelect.value;
    const userName = userNameInput.value.trim();

    if (!userName) {
        alert("Please enter your name.");
        return;
    }

    if (quizQuestions[selectedTopic]) {
        currentQuestions = quizQuestions[selectedTopic].sort(() => Math.random() - 0.5);
        currentQuestionIndex = 0;
        score = 0;
        timeLeft = 15;

        scoreCount.textContent = score;
        hideAllMenus();
        quizArea.classList.remove("hidden");

        displayQuestion();
        startTimer();
    } else {
        alert("Please select a valid topic.");
    }
});
;


function displayQuestion() {
    clearInterval(timer);
    timeLeft = 15;
    timerDisplay.textContent = timeLeft;

    const { question, options } = currentQuestions[currentQuestionIndex];
    questionElement.textContent = question;

    optionsContainer.innerHTML = options
        .map(option => `<button class="option-btn" onclick="checkAnswer('${option}')">${option}</button>`)
        .join('');

    nextQuestionButton.classList.add("hidden");
    startTimer();
}

function checkAnswer(selectedOption) {
    clearInterval(timer);

    const correctAnswer = currentQuestions[currentQuestionIndex].answer;

    
    const optionButtons = document.querySelectorAll(".option-btn");
    optionButtons.forEach(button => button.disabled = true);

    if (selectedOption === correctAnswer) {
        score++;
        scoreCount.textContent = score;
    }

    nextQuestionButton.classList.remove("hidden");
}


function startTimer() {
    clearInterval(timer); 
    timeLeft = 15; 
    timerDisplay.textContent = timeLeft;

    timer = setInterval(() => {
        timeLeft--;
        timerDisplay.textContent = timeLeft;

        if (timeLeft <= 0) {
            clearInterval(timer);
            moveToNextQuestion();
        }
    }, 1000);
}

nextQuestionButton.addEventListener("click", moveToNextQuestion);

function moveToNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < currentQuestions.length) {
        displayQuestion();
    } else {
        endQuiz();
    }
}

function endQuiz() {
    clearInterval(timer);
    hideAllMenus(); 
    winAnimation.classList.remove("hidden");

    winnerName.textContent = userNameInput.value || "Player";
    finalScore.textContent = score;

    updateLeaderboard(userNameInput.value, score);
}


function updateLeaderboard(name, score) {
    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboard.push({ name, score });
    leaderboard.sort((a, b) => b.score - a.score);
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard));

    displayLeaderboard();
}

function displayLeaderboard() {
    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboardList.innerHTML = leaderboard
        .map(entry => `<li>${entry.name}: ${entry.score}</li>`)
        .join('');

    hideAllMenus(); 
    leaderboardSection.classList.remove("hidden");
}


restartButton.addEventListener("click", () => {
    hideAllMenus(); 
    document.getElementById("user-input-section").classList.remove("hidden");
    userNameInput.value = "";
});



const clearLeaderboardButton = document.getElementById("clear-leaderboard");

clearLeaderboardButton.addEventListener("click", () => {
   
    if (confirm("Are you sure you want to delete all leaderboard scores?")) {
       
        localStorage.removeItem("leaderboard");

        
        leaderboardList.innerHTML = "";
        leaderboardSection.classList.add("hidden");

        alert("Leaderboard has been cleared.");
    }
});
function hideAllMenus() {
    document.getElementById("user-input-section").classList.add("hidden");
    quizArea.classList.add("hidden");
    winAnimation.classList.add("hidden");
    leaderboardSection.classList.add("hidden");
}


function updateLeaderboard(name, score) {
    const leaderboard = JSON.parse(localStorage.getItem("leaderboard")) || [];
    leaderboard.push({ name, score });
    leaderboard.sort((a, b) => b.score - a.score);
    localStorage.setItem("leaderboard", JSON.stringify(leaderboard));

    displayLeaderboard();

  
    saveLeaderboardToExcel(name, leaderboard);
}

function saveLeaderboardToExcel(userName, data) {
    const worksheetData = [["Name", "Score"]]; 
    data.forEach(entry => worksheetData.push([entry.name, entry.score])); 

 
    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

    XLSX.utils.book_append_sheet(workbook, worksheet, "Leaderboard");

    const fileName = `${userName}_leaderboard.xlsx`;
    XLSX.writeFile(workbook, fileName);
}
function saveLeaderboardToExistingExcel(userName, newData) {
    const fileName = "leaderboard.xlsx"; 

    let workbook;
    try {
        workbook = XLSX.readFile(fileName);
    } catch (error) {
       
        workbook = XLSX.utils.book_new();
    }

    
    let worksheet;
    if (workbook.SheetNames.includes("Leaderboard")) {
        worksheet = workbook.Sheets["Leaderboard"];
    } else {
        // Create a new worksheet if it doesn't exist
        worksheet = XLSX.utils.aoa_to_sheet([["Name", "Score"]]);
        XLSX.utils.book_append_sheet(workbook, worksheet, "Leaderboard");
    }


    const existingData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

    
    newData.forEach(entry => existingData.push([entry.name, entry.score]));

   
    const updatedWorksheet = XLSX.utils.aoa_to_sheet(existingData);
    workbook.Sheets["Leaderboard"] = updatedWorksheet;

   
    XLSX.writeFile(workbook, fileName);
}
const newData = [{ name: userName, score: score }];
saveLeaderboardToExistingExcel(userName, newData);


;
